|Site|Strength|
|---|---|
|Apple|Minimal|
|Netflix|CTA|