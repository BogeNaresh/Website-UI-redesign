Evaluated using Nielsen's heuristics.
- Visibility
- Consistency
- Error prevention
